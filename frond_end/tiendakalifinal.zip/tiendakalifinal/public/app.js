document.addEventListener('DOMContentLoaded', function() {
    const apiBase = 'http://localhost:8080/tiendakali/public/index.php?resource=prendas';
    const apiPrendasVendidas = 'http://localhost:8080/tiendakali/public/index.php?resource=prendas&action=vendidasConStock';

    async function fetchPrendas() {
        try {
            const response = await fetch(apiBase);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const prendas = await response.json();
            const $tableBody = $('#prendasTable tbody');
            $tableBody.empty();
            prendas.forEach(prenda => {
                $tableBody.append(`
                    <tr>
                        <td>${prenda.nombre}</td>
                        <td>${prenda.marca_id}</td>
                        <td>${prenda.stock}</td>
                        <td>${prenda.talla}</td>
                        <td>${prenda.precio}</td>
                        <td>
                            <button class="btn btn-warning btn-sm edit-btn" data-id="${prenda.idPrenda}">Editar</button>
                            <button class="btn btn-danger btn-sm delete-btn" data-id="${prenda.idPrenda}">Eliminar</button>
                        </td>
                    </tr>
                `);
            });
        } catch (error) {
            console.error('Error fetching prendas:', error);
        }
    }

    async function fetchPrendasVendidas() {
        try {
            const response = await fetch(apiPrendasVendidas);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const prendas = await response.json();
            const $tableBody = $('#prendasTable tbody');
            $tableBody.empty();
            prendas.forEach(prenda => {
                $tableBody.append(`
                    <tr>
                        <td>${prenda.nombre}</td>
                        <td>${prenda.marca_id}</td>
                        <td>${prenda.stock}</td>
                        <td>${prenda.talla}</td>
                        <td>${prenda.precio}</td>
                        <td>
                            <button class="btn btn-warning btn-sm edit-btn" data-id="${prenda.idPrenda}">Editar</button>
                            <button class="btn btn-danger btn-sm delete-btn" data-id="${prenda.idPrenda}">Eliminar</button>
                        </td>
                    </tr>
                `);
            });
        } catch (error) {
            console.error('Error fetching prendas vendidas:', error);
        }
    }

    $('#loadPrendas').click(function() {
        fetchPrendas();
    });

    $('#loadPrendasVendidas').click(function() {
        fetchPrendasVendidas();
    });

    $('#prendaForm').submit(async function(e) {
        e.preventDefault();
        const idPrenda = $('#prendaId').val(); // Obtén el ID si existe
        const nombre = $('#nombre').val();
        const marca = $('#marca').val();
        const stock = $('#stock').val();
        const talla = $('#talla').val();
        const precio = $('#precio').val();
        const inventario = $('#inventario').val();
        const url = idPrenda ? `${apiBase}&idPrenda=${idPrenda}` : apiBase;
        const method = idPrenda ? 'PUT' : 'POST';
        const data = JSON.stringify({ nombre, marca_id: marca, stock, talla, precio, idInventario: inventario });

        try {
            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: data
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            await fetchPrendas();
            $('#prendaForm')[0].reset();
            $('#submitBtn').text('Agregar');
            $('#formTitle').text('Agregar Prenda');
        } catch (error) {
            console.error('Error saving prenda:', error);
        }
    });

    $('#prendasTable').on('click', '.edit-btn', function() {
        const idPrenda = $(this).data('id');
        fetch(`${apiBase}&idPrenda=${idPrenda}`)
            .then(response => response.json())
            .then(prenda => {
                $('#prendaId').val(prenda.idPrenda);
                $('#nombre').val(prenda.nombre);
                $('#marca').val(prenda.marca_id);
                $('#stock').val(prenda.stock);
                $('#talla').val(prenda.talla);
                $('#precio').val(prenda.precio);
                $('#inventario').val(prenda.idInventario || '');
                $('#submitBtn').text('Actualizar');
                $('#formTitle').text('Actualizar Prenda');
            })
            .catch(error => console.error('Error fetching prenda details:', error));
    });

    $('#prendasTable').on('click', '.delete-btn', function() {
        const idPrenda = $(this).data('id');
        fetch(`${apiBase}&idPrenda=${idPrenda}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return fetchPrendas();
            })
            .catch(error => console.error('Error deleting prenda:', error));
    });
});
